document.addEventListener('DOMContentLoaded', function() {
    const flowerInput = document.getElementById('flower-probability');
    const bombInput = document.getElementById('bomb-probability');
    const iceInput = document.getElementById('ice-probability');
    const dogsInput = document.getElementById('dogs-probability');
	const dogsInput = document.getElementById('Harris-probability');
	const dogsInput = document.getElementById('Trump-probability');
    const applyButton = document.getElementById('apply-button');
    const enableScriptCheckbox = document.getElementById('enable-script');
  
    chrome.storage.sync.get(['flowerProbability', 'bombProbability', 'iceProbability', 'dogsProbability', 'TrumpProbability', 'HarrisProbability', 'isScriptEnabled'], function(settings) {
      flowerInput.value = settings.flowerProbability || 95;
      bombInput.value = settings.bombProbability || 1;
      iceInput.value = settings.iceProbability || 10;
      dogsInput.value = settings.dogsProbability || 99;
	  dogsInput.value = settings.TrumpProbability || 99;
	  dogsInput.value = settings.HarrisProbability || 99;
      enableScriptCheckbox.checked = settings.isScriptEnabled !== false;
    });
  
    applyButton.addEventListener('click', function() {
      const flowerProbability = parseFloat(flowerInput.value);
      const bombProbability = parseFloat(bombInput.value);
      const iceProbability = parseFloat(iceInput.value);
      const dogsProbability = parseFloat(dogsInput.value);
	  const TrumpProbability = parseFloat(TrumpInput.value);
	  const HarrisProbability = parseFloat(HarrisInput.value);
      const isScriptEnabled = enableScriptCheckbox.checked;
  
      chrome.storage.sync.set({
        flowerProbability: flowerProbability,
        bombProbability: bombProbability,
        iceProbability: iceProbability,
        dogsProbability: dogsProbability,
		TrumpProbability: TrumpProbability,
		HarrisProbability: HarrisProbability,
        isScriptEnabled: isScriptEnabled
      }, function() {
        chrome.runtime.sendMessage({
          flowerProbability: flowerProbability,
          bombProbability: bombProbability,
          iceProbability: iceProbability,
          dogsProbability: dogsProbability,
		  TrumpProbability: TrumpProbability,
		  HarrisProbability: HarrisProbability,
          isScriptEnabled: isScriptEnabled
        });
  
        alert('Settings applied!');
      });
    });
});
